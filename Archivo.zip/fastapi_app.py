import os, json, sqlite3
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any, Dict
from semantic_layer import build_semantic_layer

ANTHROPIC_API_KEY = os.getenv("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")
try:
    from anthropic import Anthropic
    anthropic_client = Anthropic(api_key=ANTHROPIC_API_KEY) if ANTHROPIC_API_KEY else None
except Exception:
    anthropic_client = None

DB_PATH = os.getenv("DB_PATH", "db.sqlite")
app = FastAPI(title="Semantic RAG-to-SQL API", version="1.0")

class AskRequest(BaseModel):
    question: str
    max_rows: int = 100
    temperature: float = 0.0

class AskResponse(BaseModel):
    sql: str
    rows: list
    rowcount: int
    explanation: str

def generate_sql_with_claude(question: str, semantic_json: Dict[str, Any], temperature: float = 0.0) -> str:
    if not anthropic_client:
        raise RuntimeError("No ANTHROPIC_API_KEY configurado. Establécelo para habilitar NL2SQL.")
    prompt = f"""Eres un asistente que traduce preguntas a SQL seguro (solo SELECT) para SQLite.
Utiliza EXCLUSIVAMENTE las tablas, columnas y relaciones de esta capa semántica (JSON):
{json.dumps(semantic_json, ensure_ascii=False, indent=2)}

Reglas:
- Devuelve solo SQL válido de lectura (SELECT ...), sin comentarios.
- Usa JOINs coherentes con las relaciones (fk y heurísticas).
- Aplica filtros, agrupaciones y orden si la pregunta lo requiere.
- Limita el resultado con LIMIT 100 por defecto si no se especifica.

Pregunta: {question}
SQL:"""
    msg = anthropic_client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=400,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}]
    )
    text = "".join(getattr(p, "text", "") for p in (msg.content or []))
    return text.strip().strip("` ")

@app.get("/schema")
def schema():
    return build_semantic_layer(DB_PATH)

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    sl = build_semantic_layer(DB_PATH)
    try:
        sql = generate_sql_with_claude(req.question, sl, req.temperature)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generando SQL: {e}")
    check = sql.strip().lower()
    if not (check.startswith("select") or check.startswith("with ")):
        raise HTTPException(status_code=400, detail=f"SQL no permitido o inválido: {sql}")
    try:
        conn = sqlite3.connect(DB_PATH); conn.row_factory = sqlite3.Row; cur = conn.cursor()
        cur.execute(sql)
        rows = [dict(r) for r in cur.fetchmany(req.max_rows)]
        return AskResponse(sql=sql, rows=rows, rowcount=len(rows),
                           explanation=f"Pregunta: {req.question}. SQL ejecutado con capa semántica inferida.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error ejecutando SQL: {e}")
    finally:
        conn.close()
