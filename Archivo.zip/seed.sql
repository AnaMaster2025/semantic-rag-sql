DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  country TEXT
);

CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  sku TEXT UNIQUE,
  name TEXT NOT NULL,
  category TEXT,
  price REAL NOT NULL
);

CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  order_date TEXT NOT NULL,
  status TEXT,
  FOREIGN KEY(customer_id) REFERENCES customers(id)
);

CREATE TABLE order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id),
  FOREIGN KEY(product_id) REFERENCES products(id)
);

INSERT INTO customers (id, name, email, country) VALUES
  (1, 'Ana López', 'ana@example.com', 'ES'),
  (2, 'Carlos Ruiz', 'carlos@example.com', 'MX'),
  (3, 'Marie Curie', 'marie@example.com', 'FR');

INSERT INTO products (id, sku, name, category, price) VALUES
  (1, 'SKU-RED-TSHIRT', 'Camiseta Roja', 'Ropa', 19.99),
  (2, 'SKU-BLU-MUG', 'Taza Azul', 'Hogar', 7.5),
  (3, 'SKU-BLK-JEANS', 'Vaqueros Negros', 'Ropa', 39.0);

INSERT INTO orders (id, customer_id, order_date, status) VALUES
  (100, 1, '2025-08-01', 'shipped'),
  (101, 1, '2025-08-07', 'processing'),
  (102, 2, '2025-08-03', 'cancelled');

INSERT INTO order_items (id, order_id, product_id, quantity, unit_price) VALUES
  (1000, 100, 1, 2, 19.99),
  (1001, 100, 2, 1, 7.5),
  (1002, 101, 3, 1, 39.0),
  (1003, 102, 2, 4, 7.5);
