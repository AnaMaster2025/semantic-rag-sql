import sys, json, sqlite3, pathlib,os
from typing import Any, Dict, Optional
from mcp.server.fastmcp import FastMCP
from semantic_layer import build_semantic_layer

mcp = FastMCP("semantic-rag-sql")

def _resolve_db(inline_path: Optional[str]) -> pathlib.Path:
    if inline_path:
        return pathlib.Path(inline_path).expanduser().resolve()
    env_p = os.getenv("DB_PATH")
    if env_p:
        return pathlib.Path(env_p).expanduser().resolve()
    # Fallback: db.sqlite en el MISMO directorio que este archivo
    here = pathlib.Path(__file__).parent
    return (here / "db.sqlite").resolve()

@mcp.tool()
async def get_semantic_layer(db_path: Optional[str] = None) -> Dict[str, Any]:
    p = _resolve_db(db_path)
    return build_semantic_layer(str(p))

@mcp.tool()
async def run_sql(sql: str, db_path: Optional[str] = None, limit: int = 1000) -> Dict[str, Any]:
    q = sql.strip().lower()
    if q.startswith(("update","delete","insert","drop","alter","create","pragma")):
        return {"error": "Solo se permiten SELECT/CTE (lectura)."}
    p = _resolve_db(db_path)
    if not p.exists():
        return {"error": f"DB no encontrada: {p}"}
    try:
        conn = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchmany(limit)
        cols = [c[0] for c in cur.description] if cur.description else []
        data = [{cols[i]: r[i] for i in range(len(cols))} for r in rows]
        return {"rows": data, "rowcount": len(data), "db": str(p)}
    except Exception as e:
        return {"error": str(e), "db": str(p)}
    finally:
        try: conn.close()
        except: pass
        
@mcp.tool()
async def anthropic_env_check() -> str:
    """Comprueba si el proceso tiene ANTHROPIC_API_KEY (no hace llamadas a la API)."""
    import os, sys
    key = os.getenv("ANTHROPIC_API_KEY")
    py = sys.executable
    if key:
        return f"OK: ANTHROPIC_API_KEY presente (prefijo: {key[:10]}…) · py={py}"
    else:
        return f"SIN CLAVE: defínela en el 'env' del JSON de Claude · py={py}"

@mcp.tool()
async def anthropic_ping(model: str = "claude-3-haiku-20240307") -> str:
    """Llama a la API de Anthropic con la clave del entorno y devuelve un eco corto."""
    import os, sys
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return "SIN CLAVE: ANTHROPIC_API_KEY no está en este proceso"
    try:
        from anthropic import Anthropic
        client = Anthropic(api_key=key)
        msg = client.messages.create(
            model=model,
            max_tokens=8,
            messages=[{"role": "user", "content": "ping"}]
        )
        text = getattr(msg.content[0], "text", str(msg.content))[:40]
        return f"OK: Claude respondió · model={model} · py={sys.executable} · '{text}'"
    except Exception as e:
        return f"ERROR llamando a Anthropic: {type(e).__name__}: {e}"
@mcp.tool()
async def db_env_check() -> str:
    import os, pathlib
    p = os.getenv("DB_PATH")
    return f"DB_PATH={p} · exists={pathlib.Path(p or '').exists()}"

if __name__ == "__main__":
    print("🚀 MCP server 'semantic-rag-sql' (STDIO) iniciado", file=sys.stderr)
    mcp.run(transport="stdio")
